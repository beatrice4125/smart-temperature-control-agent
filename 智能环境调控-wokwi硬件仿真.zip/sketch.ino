#include <DHT.h>
#define DHTPIN 2
#define DHTTYPE DHT22  

DHT dht(DHTPIN, DHTTYPE);

void setup() {
  Serial.begin(9600); // 波特率和Python里一致
  dht.begin();
}

void loop() {
  float temp = dht.readTemperature();
  float hum = dht.readHumidity();
  
  // 按固定格式发送：温度,湿度
  Serial.print(temp);
  Serial.print(",");
  Serial.println(hum);
  
  delay(1000); // 每秒发一次
}